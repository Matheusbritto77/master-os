<?php return array (
  'facade/ignition' => 
  array (
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'swooletw/laravel-swoole' => 
  array (
    'aliases' => 
    array (
      'Room' => 'SwooleTW\\Http\\Websocket\\Facades\\Room',
      'Table' => 'SwooleTW\\Http\\Server\\Facades\\Table',
      'Server' => 'SwooleTW\\Http\\Server\\Facades\\Server',
      'Websocket' => 'SwooleTW\\Http\\Websocket\\Facades\\Websocket',
    ),
    'providers' => 
    array (
      0 => 'SwooleTW\\Http\\LaravelServiceProvider',
    ),
  ),
);